SHELL=bash
source init.sh

__enhancd::filepath::split_list echo

bats test
